import logo from './logo.svg';
import './App.css';
import MainMenu from './components/pages/mainMenu/MainMenu';
function App() {
  return (
    <div className="App">
      <MainMenu/>
    </div>
  );
}

export default App;
